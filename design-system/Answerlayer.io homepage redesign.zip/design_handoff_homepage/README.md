# Handoff: AnswerLayer Marketing Home Page

## Overview
A new, conversion-focused home page for **answerlayer.io**. It walks an executive
visitor (CDO / VP Data / CTO) through the core narrative from the sales deck —
**problem → semantic layer → single API contract → runs-in-your-cloud → pricing** —
and drives them to a single primary action: **Sign up** (with a secondary "Talk to us").

This does **not** replace the existing site shell. It is a new `index.astro` body that
lives inside the current `Layout.astro` and reuses `Header.astro` and `Footer.astro`.

## About the Design Files
The file in this bundle — `AnswerLayer Home (Final).dc.html` — is a **design reference
created in HTML/React**, a prototype showing the intended look and behavior. It is **not**
production code to copy directly. The task is to **recreate this design natively in the
existing Astro + Tailwind v4 codebase** (`AnswerLayer/answerlayer-website`), using the
established design system rather than porting inline styles.

Almost everything in the mock already exists as a token or class in
`src/styles/global.css`. **Use those — do not hardcode hex values or font stacks.**

## Fidelity
**High-fidelity.** Final colors, typography, spacing, copy, and layout. Recreate
pixel-closely using the codebase's existing tokens/classes (Tailwind `navy-*` theme,
`font-display`/`font-mono`, `.crt-*` utilities). The mock's inline hex/fonts are only
there because the prototype can't import the Astro theme — see the token map below to
translate each one back to an existing token.

---

## Target codebase facts (already in the repo)
- **Framework:** Astro, Tailwind CSS v4 (`@theme` in `src/styles/global.css`).
- **Layout:** `src/layouts/Layout.astro` renders `<Header />`, `<main>` (slot), `<Footer />`,
  a `.scanline-overlay`, and sets `<body class="crt-screen">`. `<main>` currently has
  `padding-top: 2rem`.
- **Header:** `src/components/Header.astro` — sticky, `border-b-2 border-navy-900`, logo +
  nav (Customers, Trust, Architecture, Docs, Blog, About) + a bordered **Deploy** button.
- **Footer:** `src/components/Footer.astro` — mono uppercase navy-600 links + a **live
  ticking clock** (`© YYYY MM DD HH:MM:SS AnswerLayer`). The mock reproduces this; in the
  real build just keep the existing Footer component.
- **Current home:** `src/pages/index.astro` pulls a single `home.md` "technical card".
  This handoff **replaces that body** with the full marketing page below.

### Implementation note — full-bleed hero
The hero and several sections are **full-bleed** (dark `navy-950` background edge-to-edge).
`Layout.astro`'s `<main>` has `padding-top: 2rem`, which would inset the hero. Recommended:
add an optional `home`/`flush` prop to `Layout.astro` that drops the `<main>` top padding
(and lets sections control their own spacing) for this page only. Keep Header sticky.

---

## Design tokens → existing system

All of these are already defined in `src/styles/global.css`. The mock's hex on the left,
the token to use on the right.

### Color (navy palette + semantic)
| Mock hex | Use this token | Tailwind class |
|---|---|---|
| `#0c1129` | `--color-navy-950` | `navy-950` |
| `#151c3f` | `--color-navy-900` | `navy-900` |
| `#1f2858` | `--color-navy-800` | `navy-800` |
| `#2a3477` | `--color-navy-700` | `navy-700` |
| `#384393` | `--color-navy-600` | `navy-600` |
| `#4a57b4` | `--color-navy-500` | `navy-500` |
| `#6275c7` | `--color-navy-400` | `navy-400` |
| `#8997d6` | `--color-navy-300` | `navy-300` |
| `#aebce5` | `--color-navy-200` | `navy-200` |
| `#dbe1f3` | `--color-navy-100` | `navy-100` |
| `#eef1fa` | `--color-navy-50` | `navy-50` |
| `#f1f4f9` | `--color-background` | `bg-background` |
| `#374151` | body text | `text-gray-700` |
| `#5b6377` | muted label/caption | `text-gray-500/600` |
| `#ffffff` | card surface | `bg-white` |

### Typography (already in `@theme`)
- **Display / headings:** `--font-display` = Space Grotesk. Headings are **UPPERCASE**,
  weight **700**, `letter-spacing: -0.01em` to `-0.02em`, tight line-height (1.04–1.1).
- **Body:** `--font-body` = `"MS Sans Serif", "Microsoft Sans Serif", Tahoma, sans-serif`.
  The mock additionally loads the repo's **W95FA** pixel font (`design-system/public/fonts/`)
  and prepends it to the stack for the authentic retro body look — optional but recommended;
  if used, `@font-face` it in `global.css` and set body stack to
  `"W95FA","MS Sans Serif",Tahoma,sans-serif`.
- **Mono (eyebrows, labels, footer, code):** `--font-mono` = Space Mono. UPPERCASE,
  `letter-spacing: .14em–.18em`.

### CRT / brutalist utilities (already in `global.css`)
- `.crt-text` — chromatic-aberration text-shadow. Apply to the logo, hero `<h1>`, and the
  dark CTA headings (the mock approximates this inline).
- `.scanline-overlay` — already rendered globally by `Layout.astro`; **don't re-add it**.
  The mock's `showScanlines` toggle is prototype-only.
- **Double-border "technical card":** 2px `navy-900` border with a `::before` inset `-6px`
  1px `navy-300` border. `global.css` has `.technical-border`; the mock builds it inline as
  `border:2px solid navy-900` + an absolute inset `-6px` `1px solid navy-300` child.

### Spacing & layout
- Content max-width: **1120px**, centered, `padding: 0 28px` (use `container mx-auto px-6/7`).
- Section vertical padding: **~88px** (`py-22`/`py-24`).
- Standard gap between grid cards: **14–18px**.

### Assets
- **Logo:** `public/logo.svg` (already in repo) — rounded navy square, "A" + DB cylinder.
- **Font:** `design-system/public/fonts/w95font*.woff2` (already in repo) if using W95FA.
- No photography / no icons — the aesthetic is type + borders + ASCII-style diagrams only.

---

## Page structure (section by section)

Order, top to bottom. Each `<section>` is full-width; inner content constrained to 1120px.

### 1. Header (existing component — keep as-is)
Sticky, navy-950 background variant acceptable, or keep the repo's white header. The mock
darkens the header to sit on the dark hero; either is fine — match whatever you ship the
hero as. Primary nav button: label per the CTA decision (see "Open decisions").

### 2. Hero — full-bleed `navy-950`, two-column split
- **Left column (~1.02fr):**
  - Eyebrow: mono, `navy-300`, uppercase, `.18em` tracking, with an 8px `navy-400` square
    bullet — text: `The foundation for AI analytics`.
  - `<h1>` (display, uppercase, 700, `.crt-text`, clamp `36–58px`, color `navy-50`/white):
    **"The trusted layer between your data and your AI"**
  - Sub (body, `navy-200`, 18px): "Define every business concept once. Serve it to every
    agent, dashboard, and model through a single governed API — running entirely inside your
    own cloud."
  - Buttons (flex, gap 14px): **[Sign up free]** solid light (`bg-background text-navy-950`,
    2px border) → `signupUrl`; **[Talk to us]** outline `navy-400` border, light text →
    `contactUrl`.
- **Right column (~0.98fr): the schematic** (the hero's signature visual) — vertical stack:
  - Row of 3 bordered chips (`navy-400` border, light text): **Agents · Dashboards · ML**
  - Mono connector centered: `↑  API CONTRACT  ↑` (navy-300)
  - Center block: 2px **white** border, `navy-900` fill — **AnswerLayer** (display 18px) +
    mono caption `SEMANTIC LAYER · GOVERNED` (navy-300)
  - Mono connector: `↓  IN PLACE  ↓`
  - Row of 3 chips (`navy-700` border, `navy-800` fill, navy-200 text):
    **Warehouse · Database · Sources**

### 3. Problem — `background` (light), centered
- Eyebrow: `The problem`.
- `<h2>` (display uppercase, navy-900, clamp 28–42px): **"Ask an LLM one question. Get five answers."**
- Sub (body 17px, gray-700, max 40em, centered): "There's no known-correct answer to
  retrieve, and one question has many defensible definitions — so the model guesses,
  confidently."
- A centered mono query chip (2px navy-900 border, white): `> "What was revenue last quarter?"`
- Down arrow (mono, navy-600).
- **4-up grid** of bordered answer cards (`navy-200` border, white), each: big display dollar
  value (navy-900, 22px, 700) + a mono caption of the interpretation:
  - `$24.8M` — `GROSS · BOOKED · CLOSE DATE`
  - `$21.3M` — `NET · RECOGNIZED · SHIP DATE`
  - `$23.1M` — `BOOKED · EUR @ SPOT`
  - `$19.9M` — `RECOGNIZED · SHIP DATE`
  - *(Values are illustrative — they dramatize "many defensible definitions, no ground truth".)*
- Punchline (display, 600, navy-900, clamp 19–24px, centered, max 24em):
  **"A confident wrong number is worse than no number."**

### 4. The answer — full-bleed `navy-50`, bordered top/bottom (2px navy-900)
- Eyebrow: `The answer`.
- `<h2>`: **"Define it once. Govern it everywhere."**
- Sub: "A semantic layer is one trusted, governed place that defines what every business
  concept means and how it maps to the underlying data. These six primitives are the whole model."
- **3-column grid (2 rows) of definition cards** (2px navy-900 border, white, padded), each
  with a mono `0N` index top-right, a display uppercase title, and a body definition:
  1. **Entities** — The nouns of your business: customers, orders, accounts.
  2. **Relationships** — How entities join — defined once and reused.
  3. **Dimensions** — The ways you slice: region, plan, channel.
  4. **Measures** — Raw aggregations: sum of amount, count of orders.
  5. **Metrics** — Governed business numbers: net revenue, active users.
  6. **Filters** — Shared definitions of "active," "paid," "churned."

### 5. How it fits — `background` (light)
- Eyebrow: `How it fits`.
- `<h2>`: **"Every consumer speaks business, not SQL"**
- **Horizontal flow**, grid `1fr auto 1.1fr auto 1fr`, vertically centered:
  - Left stack of 3 chips (2px navy-900 border, white): **Agents / Dashboards / ML features**
  - Mono arrow `→` (navy-600)
  - Center: double-border technical card, `navy-900` fill — **AnswerLayer** (display 22px,
    light) + mono caption "one API contract / governed definitions" (navy-200)
  - Mono arrow `→`
  - Right stack of 3 chips (2px navy-700 border, `navy-100` fill, navy-800 text):
    **Warehouse / Database / More sources**

### 6. Runs in your cloud — full-bleed `navy-950` (inverted)
- Eyebrow: `The differentiator` (navy-300).
- `<h2>` (light, `.crt-text`): **"It runs in your cloud"**
- Sub (navy-200): "Bring Your Own Cloud — the full stack deploys inside your own account.
  No third-party SaaS upload. Data never leaves."
- A **dashed `navy-400` bordered container** labeled `YOUR CLOUD ACCOUNT` (mono tab,
  top-left, navy-950 bg cutout). Inside:
  - A white-bordered `navy-900` block: **"Full AnswerLayer stack — installed here"** + caption
    "All resources provisioned and managed within your account." (navy-200)
  - 3-column row of guarantees, each a display uppercase title with a 2px `navy-400`
    bottom border + body caption (navy-300):
    - **Data sovereignty** — Data stays in your jurisdiction and your accounts.
    - **Privacy & protection** — No third-party SaaS upload — often a hard requirement.
    - **No tradeoff** — Modern AI analytics and governance, together.

### 7. Pricing — `background` (light)
- Eyebrow: `Pricing`.
- `<h2>`: **"Simple, and built for design partners"**
- A **single 2px navy-900 bordered box split into two columns** (divider 2px navy-900):
  - **Platform fee** — mono label; display `$15K` + mono `/ yr`; body "Flat. The full
    semantic-layer stack, deployed in your cloud."
  - **Embedded users** — mono label; display `$1–10` + mono `/ user / mo`; body "Tiered by
    volume. You pay only for active users."
- Below: a **2px navy-900 bordered `navy-50` strip**: mono `DESIGN-PARTNER PERK` + display
  "3 months free Forward-Deployed Engineer (FDE) service."

### 8. Final CTA — full-bleed `navy-900`, centered
- `<h2>` (light, `.crt-text`, clamp 30–48px): **"One source of truth for every agent you ship"**
- Sub (navy-200): "Deploy the semantic layer in your own cloud and stop shipping confident
  wrong numbers."
- Buttons: **[Sign up free]** solid light → `signupUrl`; **[Talk to us]** outline → `contactUrl`.

### 9. Footer (existing component — keep as-is)
Use `Footer.astro` unchanged (links + live clock).

---

## Interactions & Behavior
- **Nav + in-page anchors:** header section links (`Problem`, `How it fits`, `Security`,
  `Pricing`) smooth-scroll to the matching section ids. `html { scroll-behavior: smooth }`
  is already in `global.css`/`main.css`.
- **Buttons/links hover:** solid light buttons darken to `navy-100`; outline buttons fill
  light and invert text to `navy-950`; nav links go from `navy-200/300` to white. All
  `transition` ~150ms.
- **Footer clock:** existing component, ticks every 1s.
- **Responsive:** at ≤768px collapse all two/three-column grids to single column; hero
  becomes stacked (text over schematic); use the existing Header mobile menu pattern. The
  4-up problem grid → 2-up then 1-up. Headlines already use `clamp()`.
- **No scanline toggle / no view switcher** in production — those were prototype-only props.

## CTA destinations (confirmed)
- **Primary CTA (`signupUrl`) → `/sign-up`** — all three "Sign up free" buttons (header,
  hero, final CTA) link here.
- **Secondary CTA (`contactUrl`) → `/contact`** — both "Talk to us" buttons link here.

## Files in this bundle
- `preview-standalone.html` — **open this in any browser.** A fully self-contained build of
  the design (no dependencies) showing the exact intended result, including hover states and
  the live footer clock. This is the canonical visual reference.
- `AnswerLayer Home (Final).dc.html` — the editable source of the prototype (needs the design
  tool's runtime to render; use `preview-standalone.html` to view).
- `README.md` — this document.

## Suggested implementation path
1. Add an optional flush/`home` prop to `Layout.astro` to remove `<main>` top padding for
   the home route (full-bleed hero).
2. Rewrite `src/pages/index.astro` body with the 8 sections above using Tailwind `navy-*`
   classes, `font-display`/`font-mono`, and `.crt-text` — no inline hex.
3. (Optional) `@font-face` W95FA in `global.css` and add it to `--font-body`.
4. CTAs are wired: `signupUrl` → `/sign-up`, `contactUrl` → `/contact`.
5. Verify against the mock at desktop + mobile widths.
